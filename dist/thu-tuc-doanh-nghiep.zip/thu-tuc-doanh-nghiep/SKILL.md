---
name: thu-tuc-doanh-nghiep
description: Hướng dẫn và chuẩn bị hồ sơ thủ tục doanh nghiệp theo Luật Doanh nghiệp 2020 sửa đổi 2025 và Nghị định 168/2025 — thay đổi người đại diện theo pháp luật, địa chỉ trụ sở (kể cả cập nhật theo địa giới hành chính mới), ngành nghề, vốn điều lệ (tăng, giảm, góp vốn đúng hạn 90 ngày), thành viên/cổ đông, chuyển nhượng vốn – cổ phần, kê khai thông tin chủ sở hữu hưởng lợi, lập chi nhánh – văn phòng đại diện – địa điểm kinh doanh, tạm ngừng kinh doanh, giải thể; nộp trực tuyến trên Cổng thông tin quốc gia về đăng ký doanh nghiệp, thời hạn 10 ngày, việc phải làm tiếp với thuế, ngân hàng, hóa đơn, con dấu. Dùng khi người dùng nói "đổi người đại diện", "chuyển trụ sở công ty", "tăng vốn điều lệ", "chuyển nhượng cổ phần", "chủ sở hữu hưởng lợi là gì", "mở chi nhánh", "tạm ngừng kinh doanh", "giải thể công ty", "thay đổi đăng ký kinh doanh".
---

# Thủ tục doanh nghiệp

Đọc trước: `references/nguyen-tac-chung.md`, `references/quy-dinh-phap-ly-2026.md`, `references/thu-tuc-dkdn.md`.

> Biểu mẫu đăng ký doanh nghiệp theo Thông tư 68/2025/TT-BTC; Nghị định 168/2025/NĐ-CP đã được sửa đổi bởi NĐ 296/2026 – **tải biểu mẫu mới nhất trên Cổng thông tin quốc gia về đăng ký doanh nghiệp** trước khi nộp. Cơ quan đăng ký: Phòng Đăng ký kinh doanh thuộc **Sở Tài chính** (sau hợp nhất Sở KH&ĐT vào Sở Tài chính năm 2025). [Chắc chắn về cơ quan; cần kiểm tra biểu mẫu]

## Quy trình chung
1. Xác định **loại thay đổi** và **loại hình** (TNHH 1TV, TNHH 2TV+, CP) → quyết định nội bộ cần có (quyết định chủ sở hữu / nghị quyết HĐTV / nghị quyết ĐHĐCĐ hoặc HĐQT) – tỷ lệ biểu quyết: `bieu_quyet_doanh_nghiep`; soạn nghị quyết, biên bản: skill `hop-hoi-dong-quan-tri`.
2. Hồ sơ theo `references/thu-tuc-dkdn.md`.
3. **Thời hạn**: đăng ký/thông báo thay đổi trong **10 ngày** kể từ ngày có thay đổi (Điều 30, 31 Luật DN 2020) – tính bằng `cong_ngay_lich` (hoặc theo ngày làm việc nếu văn bản quy định) [Chắc chắn về 10 ngày; kiểm tra cách tính].
4. Nộp trực tuyến (chữ ký số doanh nghiệp hoặc tài khoản định danh điện tử VNeID theo quy định hiện hành) → nhận kết quả trong 03 ngày làm việc nếu hồ sơ hợp lệ [Chắc chắn].
5. **Việc phải làm sau khi có kết quả**: checklist trong `references/thu-tuc-dkdn.md` (thuế, ngân hàng, hóa đơn điện tử, chữ ký số, hợp đồng đang hiệu lực, biển hiệu, con dấu nếu muốn đổi).

## Chủ sở hữu hưởng lợi (CSHHL)
Từ 01/7/2025 doanh nghiệp phải thu thập, lưu giữ, kê khai thông tin CSHHL khi đăng ký thành lập và khi thay đổi (Luật 76/2025/QH15; tiêu chí xác định tại Điều 17 NĐ 168/2025, đã sửa bởi NĐ 296/2026) – nhìn chung là cá nhân sở hữu trên thực tế từ một tỷ lệ vốn điều lệ trở lên (trực tiếp/gián tiếp) hoặc có quyền chi phối. **[Cần kiểm tra tỷ lệ và tiêu chí hiện hành]**. Giúp người dùng: vẽ sơ đồ sở hữu, xác định cá nhân ở cuối chuỗi, lập bảng thông tin cần kê khai, nhắc nghĩa vụ cập nhật khi thay đổi.

## Địa chỉ trụ sở sau sắp xếp địa giới (01/7/2025)
Doanh nghiệp có địa chỉ ghi theo đơn vị hành chính cũ: thường **không bắt buộc** làm thủ tục thay đổi chỉ vì sắp xếp địa giới; cập nhật khi có thay đổi khác hoặc khi doanh nghiệp có nhu cầu, miễn phí [Cần kiểm tra hướng dẫn hiện hành]. Khi soạn hợp đồng, hóa đơn: ghi địa chỉ theo ĐKDN đang hiệu lực, có thể chú thích địa chỉ mới.

## Cảnh báo thường gặp
- Góp vốn không đủ, không đúng hạn **90 ngày** kể từ ngày cấp giấy chứng nhận → phải đăng ký điều chỉnh vốn/tỷ lệ trong 30 ngày tiếp theo (Điều 47, 75, 113) [Chắc chắn].
- Chuyển nhượng vốn/cổ phần: hạn chế chuyển nhượng cổ phần phổ thông của cổ đông sáng lập trong 03 năm đầu (Điều 120) [Chắc chắn]; quyền ưu tiên mua của thành viên TNHH (Điều 52); nghĩa vụ thuế TNCN/TNDN chuyển nhượng → phối hợp kế toán [Cần kiểm tra theo luật thuế 2025].
- Thay người đại diện theo pháp luật: cập nhật ngay với ngân hàng (chữ ký mẫu), cơ quan thuế, nhà cung cấp chữ ký số; ủy quyền của người cũ chấm dứt theo nội dung ủy quyền.
- Tạm ngừng kinh doanh: thông báo chậm nhất **03 ngày làm việc** trước ngày tạm ngừng (Điều 206) [Chắc chắn]; vẫn phải nộp đủ thuế còn nợ, tiếp tục nghĩa vụ hợp đồng, người lao động.
- Giải thể: thanh toán hết nợ, nghĩa vụ thuế, BHXH trước; quyết toán thuế; đóng mã số thuế – quy trình dài, phối hợp kế toán.

## Đầu ra
Danh sách hồ sơ theo đúng trường hợp · nghị quyết/quyết định nội bộ nháp · bảng thông tin CSHHL · lịch các mốc (10 ngày, 90 ngày...) · checklist việc sau khi có kết quả.
