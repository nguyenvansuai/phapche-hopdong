---
name: tranh-chap-to-tung
description: Chuẩn bị giải quyết tranh chấp kinh doanh, thương mại, dân sự cho doanh nghiệp Việt Nam — chọn con đường (thương lượng, hòa giải thương mại, hòa giải đối thoại tại Tòa án, trọng tài thương mại – VIAC, khởi kiện), xác định cơ quan có thẩm quyền sau cải cách tòa án 01/7/2025 (Tòa án nhân dân khu vực sơ thẩm, Tòa Kinh tế cấp tỉnh phúc thẩm), kiểm tra thỏa thuận trọng tài có hiệu lực không, thời hiệu, ước tính án phí và tạm ứng án phí, soạn đơn khởi kiện (mẫu 23-DS), danh mục chứng cứ, bản tự khai, đơn yêu cầu áp dụng biện pháp khẩn cấp tạm thời, thủ tục rút gọn; sau bản án: kháng cáo (15 ngày), yêu cầu thi hành án (5 năm). Dùng khi người dùng nói "khởi kiện", "nộp đơn kiện ra tòa", "kiện ở tòa nào", "đơn khởi kiện", "trọng tài hay tòa án", "án phí bao nhiêu", "bị kiện thì làm gì", "kháng cáo", "thi hành án".
---

# Tranh chấp – tố tụng

Đọc trước: `references/nguyen-tac-chung.md`, `references/quy-dinh-phap-ly-2026.md`, `references/ho-so-to-tung.md`.

> Tranh chấp có giá trị lớn, phức tạp, có yếu tố nước ngoài, hoặc doanh nghiệp là **bị đơn** → khuyến nghị thuê luật sư. Skill giúp chuẩn bị hồ sơ, tính toán, hiểu quy trình.

## Bước 1 – Xác định con đường
1. Hợp đồng có **thỏa thuận trọng tài** hợp lệ? (chỉ định trọng tài rõ, không đồng thời "Tòa án hoặc Trọng tài" mơ hồ – rà bằng `quet_dieu_khoan_hop_dong`). Có → Tòa án phải từ chối thụ lý (trừ khi thỏa thuận vô hiệu/không thực hiện được) → nộp đơn khởi kiện tại trung tâm trọng tài đã chọn.
2. Không có → Tòa án. Cân nhắc trước: hòa giải thương mại (NĐ 22/2017) hoặc hòa giải, đối thoại tại Tòa án (Luật 2020 – khi nộp đơn, có thể chọn hòa giải trước thụ lý, miễn phí).

## Bước 2 – Thẩm quyền Tòa án (sau 01/7/2025)
- Sơ thẩm tranh chấp kinh doanh, thương mại, dân sự: **Tòa án nhân dân khu vực** [Chắc chắn về mô hình – Luật 85/2025/QH15 sửa BLTTDS]; phúc thẩm KDTM: Tòa Kinh tế TAND cấp tỉnh.
- Theo lãnh thổ: thường là tòa nơi **bị đơn** có trụ sở/cư trú; các bên có thể thỏa thuận bằng văn bản chọn tòa nơi nguyên đơn có trụ sở (Điều 39 BLTTDS); tranh chấp bất động sản: tòa nơi có bất động sản.
- Xác định TAND khu vực cụ thể theo xã/phường nơi bị đơn có trụ sở (địa giới mới) – người dùng tra danh sách phạm vi lãnh thổ trên cổng thông tin TAND tỉnh. [Cần kiểm tra cho từng vụ]
- Tranh chấp SHTT: Tòa chuyên trách SHTT (TAND khu vực tại Hà Nội, TP.HCM) [Cần kiểm tra].

## Bước 3 – Thời hiệu, chi phí
- `thoi_hieu_khoi_kien` – nếu sắp hết, ưu tiên nộp đơn ngay.
- `an_phi_so_tham` (giá trị yêu cầu) → án phí dự kiến, tạm ứng án phí (nộp sau khi tòa thông báo, thường trong 07 ngày) [Chắc chắn về thời hạn 07 ngày].
- Lãi chậm trả đến ngày nộp đơn: `lai_cham_tra`.

## Bước 4 – Hồ sơ
Mẫu và danh mục: `references/ho-so-to-tung.md` – đơn khởi kiện (mẫu số 23-DS ban hành kèm NQ 01/2017/NQ-HĐTP [Cần kiểm tra mẫu mới nếu có]), chứng cứ đánh số bút lục, bảng tính, giấy tờ pháp lý, ủy quyền. Nộp: trực tiếp, bưu chính, hoặc trực tuyến (cổng dịch vụ công của Tòa án).

## Bước 5 – Biện pháp khẩn cấp tạm thời (nếu cần)
Phong tỏa tài khoản, kê biên tài sản, cấm chuyển dịch quyền về tài sản... khi có nguy cơ tẩu tán. Người yêu cầu thường phải thực hiện biện pháp bảo đảm (nộp tiền/bảo lãnh) và chịu trách nhiệm nếu yêu cầu không đúng. [Chắc chắn về nguyên tắc]

## Bước 6 – Sau bản án
- Kháng cáo bản án sơ thẩm: **15 ngày** kể từ ngày tuyên án (đương sự vắng mặt: từ ngày nhận/niêm yết bản án) [Chắc chắn]. Quyết định: 07 ngày.
- Yêu cầu thi hành án: trong **05 năm** kể từ ngày bản án có hiệu lực – `thoi_hieu_khoi_kien` loại `yeu_cau_thi_hanh_an`; nộp tại cơ quan thi hành án dân sự có thẩm quyền.

## Khi doanh nghiệp là bị đơn
Ghi nhận ngày nhận thông báo thụ lý → thời hạn nộp văn bản ý kiến (15 ngày, có thể gia hạn) [Chắc chắn]; thu thập chứng cứ; cân nhắc yêu cầu phản tố; tham gia hòa giải; thuê luật sư.

## Đầu ra
Sơ đồ con đường giải quyết + khuyến nghị · thẩm quyền dự kiến (có nhãn) · thời hiệu · chi phí ước tính · đơn khởi kiện nháp · danh mục chứng cứ · lịch các mốc.

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Google Drive** · **Gmail** · **Google Calendar** · **Microsoft 365 (Outlook, OneDrive/SharePoint, Teams)**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Gom chứng cứ từ Drive và email thành danh mục tài liệu, chứng cứ kèm đơn khởi kiện; chỉ liệt kê tài liệu thực có.
2. Tạo nhắc hạn tố tụng trên lịch: hạn nộp tạm ứng án phí, hạn kháng cáo, phiên hòa giải, phiên xử (sau khi xác nhận).
3. Lưu dự thảo đơn khởi kiện, bản tự khai vào thư mục vụ việc trên Drive.

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
